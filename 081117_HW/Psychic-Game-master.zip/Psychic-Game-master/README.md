# Psychic Game
The Psychic Game
A simple JavaScript game that allows you to guess the letter the computer chooses.

Choose a letter from A - Z and test your psycic ability to see if you can read a computers mind!
