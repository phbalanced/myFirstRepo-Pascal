### File

* [`arrays-activity`](Unsolved/arrays-activity.html)

### Instruction

* With a partner, take a few moments to look over the code in the file above.

* Above each `console.log()` write a comment "predicting" what you think the output will be.

* **HINT:** Comments are the grayed lines that begin with `//`. These lines are ignored by JavaScript, and they allow you to explain your code. Commenting your code is an extremely useful habit to get into as it allows other developers to more easily read your code. It will also help you better understand your own applications when you look back at them.
