### File

* [`loop-tv-unsolved`](Unsolved/loop-tv-unsolved.html)

### Instructions

* Run the program in the file above.

* Then, with a partner, fill in the missing comments for each line of code.

* Make sure both of you can fully explain what each line means.

* Be prepared to share with the class!
