### File

* [`pizza-variables`](Unsolved/pizza-variables.html)

### Instructions

* Using the instructions in the file above, fill in the missing JavaScript code to create variables.

* When you are done, open the file in Chrome and check the output.

* If you successfully completed the activity, you should see a series of pop-up windows with text inside.

* Finally, look at the rest of the code and try to figure out why the text displayed the way it did.
