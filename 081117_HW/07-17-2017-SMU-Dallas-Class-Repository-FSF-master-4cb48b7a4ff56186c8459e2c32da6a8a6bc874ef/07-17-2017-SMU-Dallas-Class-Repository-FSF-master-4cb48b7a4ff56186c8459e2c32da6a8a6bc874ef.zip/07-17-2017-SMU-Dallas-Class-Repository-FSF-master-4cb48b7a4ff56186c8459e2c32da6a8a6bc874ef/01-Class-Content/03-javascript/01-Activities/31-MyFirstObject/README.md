### File

* [`car-object-unsolved`](Unsolved/car-object-unsolved.html)

### Instructions

* With a partner, spend the next few moments studying the code in the file above.

* Then write code below each comment to log the relevant information about the provided `car` object.

* **BONUS:** If you finish early, create a brand new object of your own. Slack out a snippet of the code to the class when you are done. Be creative!
