### File

* *None*

### Instructions

* Create a website (from scratch) that asks users if they eat steak.

* If they respond with "yes", write the following to the page: "Here’s a Steak Sandwich!"

* If they respond with "no", write the following to the page: "Here’s a Tofu Stir-Fry!"

* **BONUS:** Ask what the user’s birth year is. If they are under 21, alert the following: "No Sake for you!"

* **HINT:** You will need to use `document.write()` from a few slides back.
