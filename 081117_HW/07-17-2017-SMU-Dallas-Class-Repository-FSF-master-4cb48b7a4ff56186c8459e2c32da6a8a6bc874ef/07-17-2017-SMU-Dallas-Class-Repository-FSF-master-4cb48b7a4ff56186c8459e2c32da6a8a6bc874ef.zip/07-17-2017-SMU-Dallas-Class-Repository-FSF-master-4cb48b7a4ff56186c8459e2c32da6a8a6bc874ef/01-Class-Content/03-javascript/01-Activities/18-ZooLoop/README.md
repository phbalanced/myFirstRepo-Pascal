## File

* [`zoo-loop-unsolved`](Unsolved/zoo-loop-unsolved.html)

### Instructions

* Use `for` loops to rewrite the file.

* If you need help, use the code from the previous example as a guide.

* Once you think your code is functioning properly, share it with the person sitting next to you.
