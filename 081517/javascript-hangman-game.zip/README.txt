A Pen created at CodePen.io. You can find this one at https://codepen.io/cathydutton/pen/ldazc.

 A JavaScript Hangman game with canvas animatoin.